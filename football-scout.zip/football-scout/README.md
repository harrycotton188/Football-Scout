# League-adjusted football scouting

Role-based scouting scores where every stat is adjusted for league difficulty, with
uncertainty on the adjustment and an out-of-sample backtest. All data is pulled through
Python packages, refreshed daily by GitHub Actions, and browsed on a free GitHub Pages site.

| source | package | coverage | stats |
|---|---|---|---|
| `understat` | `soccerdata` | big-5 leagues | npxG, xA, shots, key passes, xG chain/build-up (reliable) |
| `sofascore` | `ScraperFC` | big-5 + 2nd divisions (Championship, Ligue 2, 2.Bundesliga, Serie B, La Liga 2), Eredivisie, Portugal, Turkey | attacking **and defensive** stats (optional: needs a headless browser and may be blocked on cloud IPs) |

League strength priors come from ClubElo (`soccerdata`). Each source is modelled separately.

## Set up
1. Push to GitHub. Settings → Pages → deploy from `main`, folder `/docs`.
2. Settings → Actions → General → Workflow permissions → **Read and write**.
3. Actions → *update-data* → **Run workflow**. It then runs daily at 06:00 UTC.
   The first Sofascore runs backfill gradually (`max_new_per_run` league-seasons per run).

Local: `pip install -r requirements.txt`, then `PYTHONPATH=src python -m scout.run [--source understat] [--offline]`.
Tests: `PYTHONPATH=src pytest`. Everything is configured in `config.yaml` (leagues, stats, score weights).

## Method
1. **League effects.** For players who change league between consecutive seasons,
   `log rate_after - log rate_before = delta[to] - delta[from] + noise`. Fitted per stat by
   weighted ridge (weights = inverse Poisson variance + `tau2` for genuine change), shrunk towards
   a prior linear in the league's mean ClubElo (so 2nd divisions get a sensible prior). Standard
   errors come from a bootstrap over movers. Everything is relative to the reference league:
   adjusted count = raw count x exp(-delta).
2. **Player rates.** Current + previous season pooled (live but stable), per 90, shrunk towards
   the role mean (empirical Bayes) so small samples don't top the table. A stat a league doesn't
   publish is NaN (never zero): it is ignored in the model and the affected score is blank.
3. **Scores.** Weighted within-role percentiles (negative weight = lower is better).
4. **Styles.** k-means within each role gives a playing-style label, used as a search filter only
   (scores stay comparable across the whole role).
5. **Backtest.** Walk-forward: for each test season, league effects are fitted only on earlier
   transitions, then used to predict how players who changed league actually performed.
   `skill = 1 - MSE(adjusted)/MSE(no adjustment)`; above 0 means the adjustment helps out of sample.
   Shown on the site's Backtest tab and in `docs/data/<source>.json`.

## How it was checked
- Synthetic data with known league effects: effects, standard errors, NaN handling, backtest skill,
  scoring, clustering and the end-to-end run are unit-tested (`tests/`).
- Ingest merge logic is tested with mocked fetchers; the site was exercised in a simulated browser.
- Package calls were checked against the installed source of `soccerdata` 2026.43 and `ScraperFC` 4.5
  (constructor and method signatures, Understat column names, ClubElo columns).
- **Not tested against the live sites.** The first real run may need small fixes (column names are
  validated and errors list what actually exists). A failed fetch never overwrites stored data.

## Limitations (read these)
- **Movers are not random.** Clubs buy after strong seasons (regression to the mean) and players age
  between seasons; both bias league effects. Treat factors as estimates, read the standard errors and
  the backtest, and check the mover counts.
- **Defensive counts are not adjusted for team context** (possession, opposition). A centre-back at a
  dominant side makes fewer tackles. The league effect captures only the typical mover.
- Sofascore xG-type stats are not published for every league/season, and its xG includes penalties
  (`np_xg` subtracts 0.76 per penalty taken, an approximation).
- Roles come from the source's coarse F/M/D (Sofascore filters by position); goalkeepers are excluded.
- Scraping is fragile and subject to each site's terms. `soccerdata` and `ScraperFC` download native
  helper libraries from GitHub on first use; on cloud IPs this can be rate-limited, in which case rerun.
- Leagues without ClubElo coverage get no strength prior (shrunk towards the reference).
