"""Walk-forward backtest of the league adjustment.

For each test transition t -> t+1: fit league effects using ONLY transitions that ended
by season t, then predict how players who changed league will move (log per-90 rate).
  baseline : no change             -> error = d
  adjusted : delta[to]-delta[from] -> error = d - dhat
skill = 1 - MSE_adjusted / MSE_baseline (>0 means the adjustment helps out of sample).
"""
import numpy as np
import pandas as pd

from . import model


def run_backtest(sp, stats, leagues, ref, z, cfg):
    seasons = sorted(sp["season"].unique())
    tests = seasons[-1 - cfg["backtest_seasons"]:-1]
    parts = []
    for t in tests:
        train = sp[sp["season"] <= t]
        mu = model.role_means(train, stats)
        mv_tr = model.build_moves(train, stats, mu, cfg["mover_min_minutes"], cfg["tau2"])
        mv_all = model.build_moves(sp[sp["season"] <= t + 1], stats, mu,
                                   cfg["mover_min_minutes"], cfg["tau2"])
        for st in stats:
            tr, te = mv_tr[st], mv_all[st]
            te = te[te["season"] == t]
            if len(tr) < 50 or len(te) < 20:
                continue
            delta, _, _ = model.fit_effects(tr, leagues, ref, z, cfg["ridge_lambda"])
            dhat = te["to"].map(delta) - te["frm"].map(delta)
            zt, zf = te["to"].map(z), te["frm"].map(z)
            dirn = np.where(zt > zf, "to_stronger", np.where(zt < zf, "to_weaker", "same"))
            parts.append(pd.DataFrame({"stat": st, "season": t + 1, "d": te["d"].values,
                                       "dhat": dhat.values, "w": te["w"].values, "dir": dirn}))
    if not parts:
        return {"note": "not enough seasons/movers for a backtest", "by_stat": [], "by_direction": []}
    df = pd.concat(parts, ignore_index=True)

    def summ(g):
        e0, e1, w = g["d"], g["d"] - g["dhat"], g["w"]
        return pd.Series({
            "n": len(g),
            "rmse_base": float(np.sqrt((e0 ** 2).mean())), "rmse_adj": float(np.sqrt((e1 ** 2).mean())),
            "skill": float(1 - (e1 ** 2).mean() / (e0 ** 2).mean()),
            "skill_w": float(1 - (w * e1 ** 2).sum() / (w * e0 ** 2).sum()),
            "bias_base": float(e0.mean()), "bias_adj": float(e1.mean())})

    by_stat = df.groupby("stat").apply(summ, include_groups=False).reset_index()
    by_dir = df.groupby("dir").apply(summ, include_groups=False).reset_index()
    overall = summ(df).to_dict()
    return {"test_seasons": sorted(int(s) for s in df["season"].unique()),
            "overall": overall,
            "by_stat": by_stat.round(4).to_dict("records"),
            "by_direction": by_dir.round(4).to_dict("records")}
