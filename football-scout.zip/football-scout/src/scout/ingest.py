"""Pull data through Python packages and keep local CSV stores (one pair per source).

Finished seasons are fetched once; the current season is refreshed every run. A failed
fetch never destroys stored data. Seasons are stored as integer start years.
"""
import datetime as dt
import time
from pathlib import Path

import numpy as np
import pandas as pd

from . import model

RAW = Path("data/raw")
BASE = ["league", "season", "team", "player", "player_id", "position", "minutes"]


def current_season(today=None):
    today = today or dt.date.today()
    return today.year if today.month >= 8 else today.year - 1


def paths(source):
    return RAW / f"{source}_player_seasons.csv", RAW / f"{source}_league_elo.csv"


def _check(df, need, what):
    missing = [c for c in need if c not in df.columns]
    if missing:
        raise KeyError(f"{what}: columns {missing} missing; available: {list(df.columns)}")


# --------------------------------------------------------------------------- Understat
def fetch_understat(scfg, years):
    import soccerdata as sd
    us = sd.Understat(leagues=list(scfg["leagues"]),
                      seasons=[model.soccerdata_season_arg(y) for y in years])
    df = us.read_player_season_stats().reset_index()   # current season is never served from cache
    _check(df, BASE + scfg["stats"], "Understat")
    df = df[BASE + scfg["stats"]].copy()
    df["season"] = df["season"].map(model.season_from_code)
    for c in ["minutes"] + scfg["stats"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["player"], df["team"], df["position"] = (df[c].astype(str) for c in ("player", "team", "position"))
    return df


# --------------------------------------------------------------------------- Sofascore
POSITIONS = (("Defenders", "D"), ("Midfielders", "M"), ("Forwards", "F"))


def _sofa_frame(df, league, year, letter, stats):
    df = df.rename(columns={"player id": "player_id", "minutesPlayed": "minutes"}).copy()
    raw_cols = set(stats) | {"expectedGoals", "penaltiesTaken"}
    for c in raw_cols:
        if c not in df.columns:
            df[c] = np.nan
        df[c] = pd.to_numeric(df[c], errors="coerce")
    # A stat column that is empty for the whole league-season is "not published" -> keep NaN.
    # Otherwise a missing value for one player means zero events.
    for c in raw_cols:
        if df[c].notna().any():
            df[c] = df[c].fillna(0)
    df["np_xg"] = (df["expectedGoals"] - 0.76 * df["penaltiesTaken"].fillna(0)).clip(lower=0)
    df["league"], df["season"], df["position"] = league, year, letter
    _check(df, BASE + stats, "Sofascore")
    return df[BASE + stats]


def fetch_sofascore(scfg, years, have_pairs, cur, cap, pause):
    from ScraperFC import Sofascore
    sofa = Sofascore()
    stats = scfg["stats"]
    frames, pairs, new = [], [], 0
    for league in scfg["leagues"]:
        try:
            by_year = {model.season_from_label(k): k for k in sofa.get_valid_seasons(league)}
        except Exception as e:
            print(f"[ingest] sofascore seasons for {league} failed: {e!r}")
            continue
        for y in years:
            if y not in by_year or ((league, y) in have_pairs and y != cur):
                continue
            if y != cur and new >= cap:
                continue
            try:
                parts = []
                for pos_name, letter in POSITIONS:
                    d = sofa.scrape_player_league_stats(by_year[y], league, "total", [pos_name])
                    if len(d):
                        parts.append(_sofa_frame(d, league, y, letter, stats))
                    time.sleep(pause)
                if parts:
                    frames.append(pd.concat(parts, ignore_index=True))
                    pairs.append((league, y))
                    new += y != cur
                    print(f"[ingest] sofascore {league} {y}: {len(frames[-1])} rows")
            except Exception as e:
                print(f"[ingest] sofascore {league} {y} failed: {e!r}")
    return (pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()), pairs


# --------------------------------------------------------------------------- Elo
def fetch_elo(scfg, years):
    import soccerdata as sd
    elo = sd.ClubElo()
    rows = []
    for y in years:
        date = min(dt.date(y + 1, 1, 1), dt.date.today())      # mid-season snapshot
        df = elo.read_by_date(str(date)).reset_index()
        df["level"] = pd.to_numeric(df["level"], errors="coerce")
        for league, spec in scfg["leagues"].items():
            country, level = spec["elo"]
            sel = df[(df["country"] == country) & (df["level"] == level)]
            if len(sel):
                rows.append((league, y, float(sel["elo"].mean())))
    return pd.DataFrame(rows, columns=["league", "season", "elo"])


# --------------------------------------------------------------------------- driver
def update(source, cfg):
    scfg = cfg["sources"][source]
    n = scfg.get("n_seasons", cfg["n_seasons"])
    cur = current_season()
    years = list(range(cur - n + 1, cur + 1))
    ps, el = paths(source)
    RAW.mkdir(parents=True, exist_ok=True)
    old = pd.read_csv(ps) if ps.exists() else pd.DataFrame(columns=BASE)

    try:
        if scfg["adapter"] == "understat":
            have = set(old["season"].astype(int))
            todo = sorted({y for y in years if y not in have} | {cur})
            new = fetch_understat(scfg, todo)
            old = pd.concat([old[~old["season"].isin(todo)], new], ignore_index=True)
            print(f"[ingest] understat seasons {todo}: {len(new)} rows")
        elif scfg["adapter"] == "sofascore":
            have = set(map(tuple, old[["league", "season"]].drop_duplicates().to_numpy().tolist()))
            new, pairs = fetch_sofascore(scfg, years, have, cur, scfg.get("max_new_per_run", 12),
                                         scfg.get("pause_seconds", 2))
            if len(new):
                keep = ~old.set_index(["league", "season"]).index.isin(pairs)
                old = pd.concat([old[keep], new], ignore_index=True)
        else:
            raise ValueError(f"unknown adapter {scfg['adapter']}")
    except Exception as e:                         # keep last good data
        print(f"[ingest] {source} fetch failed ({e!r}); keeping stored data")
    if len(old):
        old.to_csv(ps, index=False)

    try:
        old_el = pd.read_csv(el) if el.exists() else pd.DataFrame(columns=["league", "season", "elo"])
        have_el = set(old_el["season"].astype(int))
        need = [y for y in years if y not in have_el or y == cur]
        new_el = fetch_elo(scfg, need)
        old_el = pd.concat([old_el[~old_el["season"].isin(need)], new_el], ignore_index=True)
        old_el.to_csv(el, index=False)
        print(f"[ingest] {source} elo seasons {need}")
    except Exception as e:
        print(f"[ingest] {source} elo fetch failed ({e!r}); keeping stored data")
