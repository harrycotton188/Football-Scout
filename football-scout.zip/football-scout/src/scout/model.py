"""League adjustment. League effects are identified from players who changed league.

For a stat, d = log(rate_after) - log(rate_before) = delta[to] - delta[from] + noise,
where delta[l] is the log-rate in league l relative to the reference league for the
same player. Solved by weighted ridge, shrunk towards an Elo-based prior, with a
bootstrap over movers for standard errors. NaN stats (not published for a league/season)
are ignored for that stat only.
"""
import numpy as np
import pandas as pd


# ------------------------------------------------------------------ season helpers
def season_from_code(code):
    """soccerdata multi-year code '2122' -> start year 2021."""
    s = str(code)
    if len(s) == 4 and s.isdigit():
        return 2000 + int(s[:2])
    raise ValueError(f"unexpected season code {code!r}")


def season_from_label(label):
    """Sofascore label '25/26', '2025/2026' or '2025' -> start year."""
    a = str(label).strip().split("/")[0]
    return 2000 + int(a) if len(a) == 2 else int(a)


def soccerdata_season_arg(year):
    """Unambiguous season argument for soccerdata (an int like 2021 is read as 2020/21)."""
    return f"{year}-{str(year + 1)[-2:]}"


def primary_pos(p):
    toks = [t for t in str(p).split() if t != "S"]
    return toks[0] if toks else ""


# ------------------------------------------------------------------ spells
def aggregate_spells(raw, stats, roles):
    """One row per (player, season, league); counts summed (NaN stays NaN) with a role.
    `season` in `raw` must already be an integer start year."""
    df = raw.copy()
    df["pos"] = df["position"].map(primary_pos)
    key = ["player_id", "season", "league"]
    top = (df.sort_values("minutes", ascending=False)
             .drop_duplicates(key)[key + ["player", "team", "pos"]])
    agg = df.groupby(key, as_index=False).agg(
        minutes=("minutes", "sum"), **{s: (s, lambda x: x.sum(min_count=1)) for s in stats})
    sp = agg.merge(top, on=key)
    sp["role"] = sp["pos"].map(roles)
    return sp[sp["role"].notna()].reset_index(drop=True)


def role_means(sp, stats):
    """Per-90 mean by role for each stat (rows where the stat exists): {stat: Series}."""
    out = {}
    for st in stats:
        ok = sp[sp[st].notna()]
        g = ok.groupby("role")
        out[st] = g[st].sum() / (g["minutes"].sum() / 90)
    return out


def league_z(elo_df, leagues, ref):
    """Elo-based league strength (per 100 Elo) relative to the reference league."""
    m = elo_df.groupby("league")["elo"].mean() if len(elo_df) else pd.Series(dtype=float)
    base = m.get(ref, m.mean() if len(m) else 0.0)
    return {l: float((m[l] - base) / 100) if l in m.index else 0.0 for l in leagues}


# ------------------------------------------------------------------ movers
def build_moves(sp, stats, mu, min_minutes, tau2, pseudo=0.5):
    """Consecutive-season league changes -> {stat: DataFrame(season, frm, to, d, w)}."""
    a, b = sp.copy(), sp.copy()
    b["season"] -= 1
    m = a.merge(b, on=["player_id", "season"], suffixes=("_a", "_b"))
    m = m[(m.league_a != m.league_b)
          & (m.minutes_a >= min_minutes) & (m.minutes_b >= min_minutes)]
    out = {}
    for st in stats:
        mm = m[m[st + "_a"].notna() & m[st + "_b"].notna()]
        prior = mm["role_a"].map(mu[st])
        # tiny pseudo-count only to avoid log(0); heavier smoothing would bias d towards 0
        ra = (mm[st + "_a"] + pseudo) / (mm.minutes_a / 90 + pseudo / prior)
        rb = (mm[st + "_b"] + pseudo) / (mm.minutes_b / 90 + pseudo / prior)
        var = 1 / (mm[st + "_a"] + 1) + 1 / (mm[st + "_b"] + 1) + tau2
        out[st] = pd.DataFrame({"season": mm["season"].values,
                                "frm": mm.league_a.values, "to": mm.league_b.values,
                                "d": (np.log(rb) - np.log(ra)).values,
                                "w": (1 / var).values})
    return out


# ------------------------------------------------------------------ estimation
def _design(mv, leagues):
    idx = {l: i for i, l in enumerate(leagues)}
    n = len(mv)
    X = np.zeros((n, len(leagues)))
    X[np.arange(n), mv["to"].map(idx).to_numpy()] += 1
    X[np.arange(n), mv["frm"].map(idx).to_numpy()] -= 1
    return X, mv["d"].to_numpy(), mv["w"].to_numpy()


def _solve(X, d, w, zv, lam):
    zz = X @ zv
    den = (w * zz * zz).sum()
    beta = (w * zz * d).sum() / den if den > 0 else 0.0
    d0 = beta * zv                                   # Elo-based prior mean
    A = X.T @ (w[:, None] * X) + lam * np.eye(len(zv))
    u = np.linalg.solve(A, X.T @ (w * (d - X @ d0)))
    return d0 + u, beta


def fit_effects(mv, leagues, ref, z, lam, n_boot=0, seed=0):
    """Returns (delta Series rel. to ref, elo slope beta, bootstrap SE Series or None)."""
    r = leagues.index(ref)
    zv = np.array([z[l] for l in leagues])
    if len(mv) == 0:
        zero = pd.Series(0.0, index=leagues)
        return zero, 0.0, (zero if n_boot else None)
    X, d, w = _design(mv, leagues)
    delta, beta = _solve(X, d, w, zv, lam)
    delta = delta - delta[r]
    se = None
    if n_boot:
        rng = np.random.default_rng(seed)
        n = len(d)
        draws = []
        for _ in range(n_boot):
            i = rng.integers(0, n, n)
            dl, _ = _solve(X[i], d[i], w[i], zv, lam)
            draws.append(dl - dl[r])
        se = pd.Series(np.std(draws, axis=0, ddof=1), index=leagues)
    return pd.Series(delta, index=leagues), beta, se


def fit_all(sp, stats, leagues, ref, z, cfg, n_boot=None):
    n_boot = cfg.get("n_boot", 0) if n_boot is None else n_boot
    mu = role_means(sp, stats)
    moves = build_moves(sp, stats, mu, cfg["mover_min_minutes"], cfg["tau2"])
    delta, se, betas = {}, {}, {}
    for st in stats:
        delta[st], betas[st], se[st] = fit_effects(
            moves[st], leagues, ref, z, cfg["ridge_lambda"], n_boot)
    first = moves[stats[0]]
    n_moves = pd.Series({l: int(((first["to"] == l) | (first["frm"] == l)).sum())
                         for l in leagues})
    se_df = pd.DataFrame(se) if n_boot else None
    return pd.DataFrame(delta), se_df, n_moves, betas


def adjust_counts(sp, delta, stats):
    """Express counts as reference-league-equivalent: y * exp(-delta[league])."""
    sp = sp.copy()
    for st in stats:
        sp[st + "_adj"] = sp[st] * np.exp(-sp["league"].map(delta[st]).astype(float))
    return sp
