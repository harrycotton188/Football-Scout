"""python -m scout.run [--source NAME] [--offline]     (run from the repo root)"""
import argparse
import datetime as dt
import json
import math
import traceback
from pathlib import Path

import pandas as pd
import yaml

from . import backtest, ingest, model, scoring, styles

OUT = Path("docs/data")


def _num(x, nd=3):
    return None if pd.isna(x) else round(float(x), nd)


def process(source, cfg):
    scfg = cfg["sources"][source]
    stats, leagues, ref = scfg["stats"], list(scfg["leagues"]), scfg["reference_league"]
    ps, el = ingest.paths(source)
    if not ps.exists():
        print(f"[run] {source}: no stored data yet, skipping")
        return False
    raw = pd.read_csv(ps)
    elo = pd.read_csv(el) if el.exists() else pd.DataFrame(columns=["league", "season", "elo"])
    sp = model.aggregate_spells(raw, stats, scfg["roles"])
    z = model.league_z(elo, leagues, ref)

    delta, se, n_moves, _ = model.fit_all(sp, stats, leagues, ref, z, cfg)
    table = scoring.player_table(model.adjust_counts(sp, delta, stats), stats, cfg)
    neg = {st for d in scfg["scores"].values() for w in d.values() for st, v in w.items() if v < 0}
    table = styles.assign_styles(table, [s for s in stats if s not in neg],
                                 cfg["styles"], cfg["min_minutes"])
    table = scoring.add_scores(table, scfg["scores"], cfg["min_minutes"])
    bt = backtest.run_backtest(sp, stats, leagues, ref, z, cfg)

    score_names = {r: list(d) for r, d in scfg["scores"].items()}
    players = []
    for _, r in table[table["minutes"] >= cfg["min_minutes"]].iterrows():
        players.append({"player": r["player"], "team": r["team"], "league": r["league"],
                        "role": r["role"], "style": r["style"], "minutes": int(r["minutes"]),
                        "s": {n: _num(r.get(n), 1) for n in score_names[r["role"]]},
                        "a": {st: _num(r[st + "_p90"]) for st in stats}})
    factors = [{"league": l, "stat": st, "factor": _num(math.exp(delta.loc[l, st])),
                "se": _num(se.loc[l, st]) if se is not None else None,
                "n_moves": int(n_moves[l])} for l in leagues for st in stats]
    coverage = {l: sorted(int(s) for s in raw.loc[raw["league"] == l, "season"].unique()) for l in leagues}
    out = {"source": source, "updated": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
           "reference_league": ref, "scores": score_names, "stats": stats,
           "styles": {r: sorted(set(p["style"] for p in players if p["role"] == r and p["style"]))
                      for r in score_names},
           "coverage": coverage, "factors": factors, "backtest": bt, "players": players}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"{source}.json").write_text(json.dumps(out, separators=(",", ":")))
    ov = bt.get("overall", {})
    print(f"[run] {source}: {len(players)} scored players; backtest skill "
          f"{ov.get('skill', float('nan')):.3f} (n={ov.get('n', 0)})")
    return True


def write_index():
    srcs = sorted(p.stem for p in OUT.glob("*.json") if p.stem != "sources")
    (OUT / "sources.json").write_text(json.dumps(srcs))


def main(source=None, offline=False):
    cfg = yaml.safe_load(open("config.yaml"))
    names = [source] if source else list(cfg["sources"])
    failed = []
    for name in names:
        try:
            if not offline:
                ingest.update(name, cfg)
            process(name, cfg)
        except Exception:
            traceback.print_exc()
            failed.append(name)
    write_index()
    if failed:
        raise SystemExit(f"failed sources: {failed}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", help="run one source only")
    ap.add_argument("--offline", action="store_true", help="skip scraping, use stored CSVs")
    a = ap.parse_args()
    main(a.source, a.offline)
