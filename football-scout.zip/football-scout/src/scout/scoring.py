"""Pool recent seasons, shrink to role means, turn into per-role percentile scores."""
import pandas as pd


def player_table(sp_adj, stats, cfg):
    cur = sp_adj["season"].max()
    rec = sp_adj[sp_adj["season"] > cur - cfg["window_seasons"]]
    active = rec.loc[rec.season == cur, "player_id"].unique()
    rec = rec[rec.player_id.isin(active)]
    latest = (rec[rec.season == cur].sort_values("minutes", ascending=False)
              .drop_duplicates("player_id")[["player_id", "player", "team", "league", "role"]])
    t = latest.merge(rec.groupby("player_id", as_index=False)["minutes"].sum(), on="player_id")

    k = cfg["prior_minutes"] / 90
    for st in stats:                                  # per stat: only seasons where it exists
        ok = rec[rec[st + "_adj"].notna()]
        g = ok.groupby("player_id", as_index=False).agg(
            **{st + "_y": (st + "_adj", "sum"), st + "_m": ("minutes", "sum")})
        t = t.merge(g, on="player_id", how="left")
        have = t[t[st + "_m"] > 0]
        mu = have.groupby("role")[st + "_y"].sum() / (have.groupby("role")[st + "_m"].sum() / 90)
        t[st + "_p90"] = (t[st + "_y"] + k * t["role"].map(mu)) / (t[st + "_m"] / 90 + k)
    return t


def add_scores(t, cfg_scores, min_minutes):
    """Weighted within-role percentiles. Negative weight = lower is better.
    A player missing any component stat (not published for his league) gets no score."""
    t = t.copy()
    elig = t["minutes"] >= min_minutes
    for role, defs in cfg_scores.items():
        mask = elig & (t["role"] == role)
        for name, weights in defs.items():
            tot = sum(abs(w) for w in weights.values())
            col = pd.Series(0.0, index=t.index[mask])
            for st, w in weights.items():
                pct = t.loc[mask, st + "_p90"].rank(pct=True) * 100
                col = col + abs(w) * (pct if w > 0 else 100 - pct)
            t.loc[mask, name] = (col / tot).round(1)
    return t
