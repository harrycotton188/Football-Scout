"""Playing-style clusters within each role (a search filter, not part of the scores)."""
import numpy as np


def assign_styles(t, stats, k_by_role, min_minutes, seed=0):
    from sklearn.cluster import KMeans
    t = t.copy()
    t["style"] = ""
    for role, k in k_by_role.items():
        sub = t[(t["role"] == role) & (t["minutes"] >= min_minutes)]
        cols = [s + "_p90" for s in stats if len(sub) and sub[s + "_p90"].notna().all()]
        if len(sub) < max(30 * k, 60) or len(cols) < 2:
            continue
        X = np.log1p(sub[cols].to_numpy())
        Z = (X - X.mean(0)) / (X.std(0) + 1e-9)
        km = KMeans(k, n_init=10, random_state=seed).fit(Z)
        names, seen = [], {}
        for c in km.cluster_centers_:
            top = np.argsort(-c)[:2]
            n = " + ".join(cols[i][:-4] for i in top)
            seen[n] = seen.get(n, 0) + 1
            names.append(n if seen[n] == 1 else f"{n} ({seen[n]})")
        t.loc[sub.index, "style"] = [names[l] for l in km.labels_]
    return t
