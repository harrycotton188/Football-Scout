"""Synthetic data with known league effects (shared by the tests)."""
import numpy as np
import pandas as pd

LEAGUES = ["L0", "L1", "L2", "L3", "L4"]
TRUE = dict(zip(LEAGUES, [0.0, 0.10, 0.20, 0.05, 0.12]))      # log-rate vs reference L0
STATS = ["a", "b"]
BASE = {"a": 0.30, "b": 0.20}
SEASONS = list(range(2019, 2026))                             # includes 2021 on purpose


def simulate(seed=0, n_players=3000, seasons=SEASONS, nan_league=None):
    rng = np.random.default_rng(seed)
    rows = []
    for pid in range(n_players):
        ab, lg = rng.normal(0, 0.4), rng.integers(len(LEAGUES))
        pos = rng.choice(["F", "M", "D"])
        for s in seasons:
            if rng.random() < 0.25:
                lg = rng.integers(len(LEAGUES))
            minutes = int(rng.integers(500, 3000))
            row = dict(league=LEAGUES[lg], season=s, team=f"T{lg}", player=f"P{pid}",
                       player_id=pid, position=pos, minutes=minutes)
            for st in STATS:
                mu = BASE[st] * np.exp(ab + TRUE[LEAGUES[lg]] + rng.normal(0, 0.1)) * minutes / 90
                row[st] = float(rng.poisson(mu))
                if nan_league and LEAGUES[lg] == nan_league and st == "b":
                    row[st] = np.nan
            rows.append(row)
    return pd.DataFrame(rows)
