"""Ingest logic with the network mocked: merging, season handling, unpublished-stat handling."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from scout import ingest  # noqa: E402


def sofa_raw(n=40, xg=True):
    d = pd.DataFrame({"player id": range(n), "player": [f"P{i}" for i in range(n)],
                      "team id": 1, "team": "T", "minutesPlayed": 1500,
                      "tacklesWon": np.arange(n), "interceptions": 5, "expectedGoals": 3.0,
                      "penaltiesTaken": 1})
    d.loc[::2, "interceptions"] = np.nan          # missing value for a player -> zero events
    if not xg:
        d = d.drop(columns=["expectedGoals"])      # league doesn't publish xG at all
    return d


def test_sofa_frame_missing_vs_unpublished():
    stats = ["np_xg", "tacklesWon", "interceptions"]
    f = ingest._sofa_frame(sofa_raw(), "L", 2025, "D", stats)
    assert f["interceptions"].notna().all() and f.loc[0, "interceptions"] == 0   # filled
    assert np.allclose(f["np_xg"], 3.0 - 0.76)                                    # derived
    g = ingest._sofa_frame(sofa_raw(xg=False), "L", 2025, "D", stats)
    assert g["np_xg"].isna().all()                                                # unpublished -> NaN
    assert set(f.columns) == set(ingest.BASE + stats) and (f["season"] == 2025).all()


def test_update_merges_and_keeps_old_data(tmp_path, monkeypatch):
    cfg = yaml.safe_load(open(ROOT / "config.yaml"))
    cfg["n_seasons"] = 3
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(ingest, "current_season", lambda today=None: 2026)
    calls = []

    def fake_us(scfg, years):
        calls.append(list(years))
        return pd.DataFrame([dict(league="ENG-Premier League", season=y, team="T", player="P",
                                  player_id=1, position="F", minutes=1000, **{s: 1.0 for s in scfg["stats"]})
                             for y in years])
    monkeypatch.setattr(ingest, "fetch_understat", fake_us)
    monkeypatch.setattr(ingest, "fetch_elo", lambda scfg, years: pd.DataFrame(
        [("ENG-Premier League", y, 1700.0) for y in years], columns=["league", "season", "elo"]))
    ingest.update("understat", cfg)
    assert calls[-1] == [2024, 2025, 2026]
    ingest.update("understat", cfg)                      # finished seasons are not re-fetched
    assert calls[-1] == [2026]
    df = pd.read_csv(ingest.paths("understat")[0])
    assert sorted(df["season"].unique()) == [2024, 2025, 2026] and len(df) == 3

    def boom(scfg, years):
        raise RuntimeError("blocked")
    monkeypatch.setattr(ingest, "fetch_understat", boom)
    ingest.update("understat", cfg)                      # failure keeps last good data
    assert len(pd.read_csv(ingest.paths("understat")[0])) == 3
