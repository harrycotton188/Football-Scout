import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))
from scout import backtest, model, scoring, styles  # noqa: E402
import synth  # noqa: E402

CFG = dict(mover_min_minutes=450, tau2=0.1, ridge_lambda=5.0, prior_minutes=900,
           window_seasons=2, min_minutes=900, n_boot=0, backtest_seasons=3)
ROLES = {"F": "FWD", "M": "MID", "D": "DEF"}
Z0 = {l: 0.0 for l in synth.LEAGUES}


def spells(**kw):
    return model.aggregate_spells(synth.simulate(**kw), synth.STATS, ROLES)


def test_season_helpers():
    assert model.season_from_code("2122") == 2021
    assert model.season_from_code("2021") == 2020          # soccerdata multi-year code
    assert model.season_from_label("25/26") == 2025 and model.season_from_label("2025") == 2025
    assert model.soccerdata_season_arg(2021) == "2021-22"


def test_stored_seasons_are_not_reparsed():
    raw = synth.simulate(n_players=50)
    sp = model.aggregate_spells(raw, synth.STATS, ROLES)
    assert set(sp["season"]) == set(synth.SEASONS)         # 2021 must stay 2021


def test_recovers_league_effects_with_se():
    sp = spells()
    delta, se, n_moves, _ = model.fit_all(sp, synth.STATS, synth.LEAGUES, "L0", Z0, CFG, n_boot=50)
    truth = pd.Series(synth.TRUE)
    assert np.corrcoef(delta["a"], truth)[0, 1] > 0.95
    assert abs(delta["a"] - truth).max() < 0.06
    assert (se.loc[["L1", "L2"], "a"] > 0).all() and se["a"].max() < 0.05
    assert n_moves.min() > 100


def test_nan_stat_is_ignored_not_zeroed():
    sp = spells(nan_league="L2")
    delta, _, _, _ = model.fit_all(sp, synth.STATS, synth.LEAGUES, "L0", Z0, CFG)
    # stat 'b' has no data in L2: its effect there must fall back to the prior (0), not blow up
    assert abs(delta.loc["L2", "b"]) < 0.08 and abs(delta.loc["L1", "b"] - 0.10) < 0.06
    adj = model.adjust_counts(sp, delta, synth.STATS)
    assert adj.loc[adj.league == "L2", "b_adj"].isna().all()


def test_backtest_shows_out_of_sample_skill():
    sp = spells()
    bt = backtest.run_backtest(sp, synth.STATS, synth.LEAGUES, "L0", Z0, CFG)
    assert bt["overall"]["skill"] > 0.0
    assert all(r["skill"] > 0 for r in bt["by_stat"])
    assert len(bt["test_seasons"]) == 3


def test_scoring_styles_and_negative_weights():
    sp = spells(n_players=1200)
    delta, _, _, _ = model.fit_all(sp, synth.STATS, synth.LEAGUES, "L0", Z0, CFG)
    t = scoring.player_table(model.adjust_counts(sp, delta, synth.STATS), synth.STATS, CFG)
    t = styles.assign_styles(t, synth.STATS, {"FWD": 2, "MID": 2, "DEF": 2}, 900)
    assert t.loc[t.minutes >= 900, "style"].ne("").any()
    sc = {"FWD": {"x": {"a": 1.0}, "y": {"a": -1.0}}, "MID": {"x": {"a": 1.0}}, "DEF": {"x": {"a": 1.0}}}
    t = scoring.add_scores(t, sc, 900)
    f = t[t.role == "FWD"].dropna(subset=["x", "y"])
    assert np.corrcoef(f["x"], f["y"])[0, 1] < -0.99          # negative weight inverts ranking
    assert t["x"].dropna().between(0, 100).all()
