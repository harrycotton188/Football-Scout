"""End-to-end run on a synthetic stored dataset (no network)."""
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))
import synth  # noqa: E402


def test_run_offline(tmp_path, monkeypatch):
    cfg = yaml.safe_load(open(ROOT / "config.yaml"))
    stats = ["s1", "s2", "s3"]
    cfg["n_boot"] = 20
    cfg["styles"] = {"FWD": 2, "MID": 2, "DEF": 2}
    cfg["sources"] = {"toy": {
        "adapter": "none", "reference_league": "L0",
        "leagues": {l: {"elo": ["XXX", 1]} for l in synth.LEAGUES},
        "roles": {"F": "FWD", "M": "MID", "D": "DEF"}, "stats": stats,
        "scores": {r: {"main": {"s1": 0.5, "s2": 0.5}, "alt": {"s3": 1.0}} for r in ("FWD", "MID", "DEF")}}}
    (tmp_path / "data/raw").mkdir(parents=True)
    raw = synth.simulate(n_players=1500)
    rng = np.random.default_rng(1)
    raw = raw.rename(columns={"a": "s1", "b": "s2"})
    raw["s3"] = rng.poisson(raw["minutes"] / 90 * 1.5).astype(float)
    raw.to_csv(tmp_path / "data/raw/toy_player_seasons.csv", index=False)
    pd.DataFrame([(l, s, 1500 + 40 * i) for i, l in enumerate(synth.LEAGUES) for s in synth.SEASONS],
                 columns=["league", "season", "elo"]).to_csv(tmp_path / "data/raw/toy_league_elo.csv", index=False)
    (tmp_path / "config.yaml").write_text(yaml.safe_dump(cfg))
    monkeypatch.chdir(tmp_path)

    from scout import run
    run.main("toy", offline=True)
    out = json.loads((tmp_path / "docs/data/toy.json").read_text())   # must be valid JSON (no NaN)
    assert out["players"] and out["factors"] and out["backtest"]["by_stat"]
    p = out["players"][0]
    assert set(p) >= {"player", "team", "league", "role", "style", "minutes", "s", "a"}
    assert json.loads((tmp_path / "docs/data/sources.json").read_text()) == ["toy"]
